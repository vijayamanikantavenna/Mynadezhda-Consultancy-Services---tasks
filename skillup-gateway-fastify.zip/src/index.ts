import Fastify from 'fastify'
import authRoutes from './routes/auth'
import proxyRoutes from './routes/proxy'
import jwtPlugin from './plugins/jwt'

const fastify = Fastify()
fastify.register(jwtPlugin)
fastify.register(authRoutes)
fastify.register(proxyRoutes)
fastify.listen({ port: 3001 }, err => {
  if (err) throw err
  console.log('Gateway running on http://localhost:3001')
})