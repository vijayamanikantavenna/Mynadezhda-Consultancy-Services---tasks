# SkillUp Gateway (Fastify)

This is the authentication and API gateway built with **Fastify** (Node.js + TypeScript).
It handles JWT authentication, request validation, and proxies requests to the FastAPI backend.
