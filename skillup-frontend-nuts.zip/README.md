# SkillUp Frontend (Nuts.js)

This is the frontend of SkillUp built using **Nuts.js** (React-based framework).
It handles authentication, course display, user progress, and admin pages.
