# SkillUp Backend (FastAPI)

This repository is the backend API for SkillUp built with **FastAPI** (Python).
It manages courses, lessons, user progress, and database models.
