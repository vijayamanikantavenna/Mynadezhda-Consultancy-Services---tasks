from fastapi import FastAPI
from app.routes import courses, lessons, progress
from app.database import engine, Base

Base.metadata.create_all(bind=engine)
app = FastAPI()
app.include_router(courses.router, prefix="/courses")
app.include_router(lessons.router, prefix="/lessons")
app.include_router(progress.router, prefix="/progress")